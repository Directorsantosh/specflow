﻿using OpenQA.Selenium;
using SpecFlowProject.Hooks;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace SpecFlowProject.PageObjects
{
    public class LoginStepsPage
    {
        private IWebDriver driver ;
        IJavaScriptExecutor jsExecutor;
        string javascriptForHighlight = "arguments[0].setAttribute('style', 'background: green; border: 3px solid blue;');";
        private readonly By txtUserName = By.Name("txtUsername");
        private readonly By txtPassword = By.Id("txtPassword");
        private readonly By btnLogin = By.Id("btnLogin");
        private readonly By lblInvalidCredentials = By.XPath("//span[text()='Invalid credentials']");
        private readonly By lblUsernameCantBeEmpty = By.XPath("//span[text()='Username cannot be empty']");
        private readonly By lblPasswordCantBeEmpty = By.XPath("//span[text()='Password cannot be empty']");

        private readonly By hdrDashboard = By.XPath("//h1[text()='Dashboard']");
        
        public LoginStepsPage(IWebDriver driver)
        {
            this.driver = driver;
        }

        public void UserEntersUserName(string strUserName)
        {
            driver.FindElement(txtUserName).SendKeys(strUserName);
        }

        public void UserEnterPassword(string strPassword)
        {
            driver.FindElement(txtPassword).SendKeys(strPassword);
        }

        public void UserClicksOnLoginButton()
        {
            driver.FindElement(btnLogin).Click();
        }

        public void UserIsOnDashboard()
        {
            jsExecutor = (IJavaScriptExecutor)driver;
            jsExecutor.ExecuteScript(javascriptForHighlight, driver.FindElement(hdrDashboard));
            Thread.Sleep(4000);
        }

        public void UserCantBeEmpty()
        {
            jsExecutor = (IJavaScriptExecutor)driver;
            jsExecutor.ExecuteScript(javascriptForHighlight, driver.FindElement(lblUsernameCantBeEmpty));
            Thread.Sleep(4000);

        }

        public void PasswordCantBeEmpty()
        {
            jsExecutor = (IJavaScriptExecutor)driver;
            jsExecutor.ExecuteScript(javascriptForHighlight, driver.FindElement(lblPasswordCantBeEmpty));
            Thread.Sleep(4000);
        }

        public void InvalidCredentialsErrorMessage()
        {
          
                jsExecutor = (IJavaScriptExecutor)driver;
                jsExecutor.ExecuteScript(javascriptForHighlight, driver.FindElement(lblInvalidCredentials));
                Thread.Sleep(4000);
            
        }

     
    }
}
