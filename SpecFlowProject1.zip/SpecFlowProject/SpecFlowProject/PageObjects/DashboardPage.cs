﻿using OpenQA.Selenium;
using SpecFlowProject.Hooks;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace SpecFlowProject.PageObjects
{
    public class DashboardPage
    {
        public IWebDriver _driver ;
        IJavaScriptExecutor jsExecutor;
        string javascriptForHighlight = "arguments[0].setAttribute('style', 'background: green; border: 3px solid blue;');";
        private readonly By txtUserName = By.Id("txtUsername");
        private readonly By txtPassword = By.Id("txtPassword");
        private readonly By btnLogin = By.Id("btnLogin");
        private readonly By lblInvalidCredentials = By.XPath("//span[text()='Invalid credentials']");
        private readonly By lblUsernameCantBeEmpty = By.XPath("//span[text()='Username cannot be empty']");
        private readonly By lblPasswordCantBeEmpty = By.XPath("//span[text()='Password cannot be empty']");

        private readonly By hdrDashboard = By.XPath("//h1[text()='Dashboard']");
        
        public DashboardPage(IWebDriver driver)
        {
            _driver = driver;
        }

        public void UserEntersUserName(string strUserName)
        {
            _driver.FindElement(txtUserName).SendKeys(strUserName);
        }

        public void UserEnterPassword(string strPassword)
        {
            _driver.FindElement(txtPassword).SendKeys(strPassword);
        }

        public void UserClicksOnLoginButton()
        {
            _driver.FindElement(btnLogin).Click();
        }

        public void UserIsOnDashboard()
        {
            jsExecutor = (IJavaScriptExecutor)_driver;
            jsExecutor.ExecuteScript(javascriptForHighlight, _driver.FindElement(hdrDashboard));
            Thread.Sleep(4000);
        }

        public void UserCantBeEmpty()
        {
            jsExecutor = (IJavaScriptExecutor)_driver;
            jsExecutor.ExecuteScript(javascriptForHighlight, _driver.FindElement(lblUsernameCantBeEmpty));
            Thread.Sleep(4000);

        }

        public void PasswordCantBeEmpty()
        {
            jsExecutor = (IJavaScriptExecutor)_driver;
            jsExecutor.ExecuteScript(javascriptForHighlight, _driver.FindElement(lblPasswordCantBeEmpty));
            Thread.Sleep(4000);
        }

        public void InvalidCredentialsErrorMessage()
        {
           
            jsExecutor = (IJavaScriptExecutor)_driver;
            jsExecutor.ExecuteScript(javascriptForHighlight, _driver.FindElement(lblInvalidCredentials));
            Thread.Sleep(4000);
        }

     
    }
}
