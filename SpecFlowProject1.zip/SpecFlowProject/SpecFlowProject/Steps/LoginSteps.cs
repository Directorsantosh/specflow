﻿using SpecFlowProject.PageObjects;
using System;
using TechTalk.SpecFlow;
using OpenQA.Selenium;

namespace SpecFlowProject.Steps
{
    [Binding]
    public class LoginSteps
    {
        private LoginStepsPage loginStepsPage;
        public LoginSteps(LoginStepsPage _loginStepsPage)
        {
            loginStepsPage = _loginStepsPage;
        }

        [When(@"User enter user name (.*)")]
        public void WhenUserEnterUserName(string username )
        {
            loginStepsPage.UserEntersUserName(username);
        }

        [When(@"User enter password (.*)")]
        public void WhenUserEnterPassword(string password)
        {
            loginStepsPage.UserEnterPassword(password);
        }

        [Then(@"User clicks on login button")]
        public void ThenUserClicksOnLoginButton()
        {
            loginStepsPage.UserClicksOnLoginButton();
        }

        [Then(@"Verify user logged in succesfully")]
        public void ThenVerifyUserLoggedInSuccesfully()
        {
            loginStepsPage.UserIsOnDashboard();
        }

        [Then(@"Verify error message on login page for invalid credentials")]
        public void ThenVerifyerrormessageonloginpageforinvalidcredentials()
        {
            loginStepsPage.InvalidCredentialsErrorMessage();
        }

        [Then(@"Verify error message on empty user name")]
        public void ThenVerifyerrormessageonEmptyUserName()
        {
            loginStepsPage.UserCantBeEmpty();
        }

        [Then(@"Verify error message on empty password")]
        public void ThenVerifyerrormessageonEmptyPassword()
        {
            loginStepsPage.PasswordCantBeEmpty();
        }

    }
}
