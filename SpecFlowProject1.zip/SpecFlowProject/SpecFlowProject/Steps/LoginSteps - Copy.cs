﻿using System;
using TechTalk.SpecFlow;

namespace SpecFlowProject.Steps
{
    [Binding]
    public class LoginFeatureSteps
    {
        [When(@"user enter the username (.*)")]
        public void WhenUserEnterTheUsernameAdmin(string username)
        {

        }

        [When(@"User enter passwords (.*)")]
        public void WhenUserEnterPasswordsAdmin(string password)
        {
            
        }
        
        [Then(@"user clicks on submit button")]
        public void ThenUserClicksOnSubmitButton()
        {
            
        }
        
        [Then(@"verify user is on dashboard page")]
        public void ThenVerifyUserIsOnDashboardPage()
        {
          
        }
    }
}
