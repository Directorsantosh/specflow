﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System;
using TechTalk.SpecFlow;
using BoDi;

namespace SpecFlowProject.Hooks
{
    [Binding]
    public sealed class WebHooks
    {
        // For additional details on SpecFlow hooks see http://go.specflow.org/doc-hooks

        private IWebDriver _driver;
        private IObjectContainer _ObjectContainer;
        public WebHooks(IObjectContainer objectContainer)
        {
            _ObjectContainer = objectContainer;
            
        }

        [BeforeScenario]
        public void BeforeScenario()
        {
           string strDriverPath = AppDomain.CurrentDomain.BaseDirectory;
           string strDriverLatestPath = strDriverPath.Replace("\\SpecFlowPlusRunner\\netcoreapp3.1\\", "\\Drivers");
           _driver = new ChromeDriver(strDriverLatestPath);
           _ObjectContainer.RegisterInstanceAs(_driver);
           _driver.Manage().Window.Maximize();
           _driver.Navigate().GoToUrl("https://opensource-demo.orangehrmlive.com/");

            //TODO: implement logic that has to run before executing each scenario
        }

        [AfterScenario]
        public void AfterScenario()
        {

            _driver.Quit();
            //TODO: implement logic that has to run after executing each scenario
        }
        
    }
}
